clc, clear
s= tf('s');
fsw = 12000;
Tsw = 1/fsw;
L = 13e-06;
r = 0.005;
C = 400e-06;
wc = 10;
wo = 2*pi*400;
kv_n = 1.1;
bv_s = 1.1*((s^2 + (2*wc*s) + (wo)^2)/(s^2 + (2*wc*s) + (wo)^2))
bv_z = c2d(bv_s, Tsw, 'tustin')
[n1,d1] = pade((3*Tsw/2), 1);
Gd = tf(n1,d1)

[n2,d2] = pade((Tsw), 1);
Gd1 = tf(n2,d2)
Gd1_z = c2d(Gd1, Tsw, 'tustin')

Gp = 1/((L*s) + r)
Gi_ol = Gd*Gp
kp_in = 0.1;

Gr3_s = 0.1 + (0.5*s)/((s^2) + (2*wc*s) + ((3*wo)^2))
Gr3_i = (0.5*s)/((s^2) + (2*wc*s) + ((3*wo)^2))
Gr5_i = (0.5*s)/((s^2) + (2*wc*s) + ((5*wo)^2))
Gr7_i = (0.5*s)/((s^2) + (2*wc*s) + ((7*wo)^2))

Gv_s = kv_n + ((2300*s)/(s^2 + (2*wc*s) + (wo)^2))
Gr1_v = ((2300*s)/(s^2 + (2*wc*s) + (wo)^2))
Gpr_i = kp_in + Gr3_i + Gr5_i + Gr7_i

Gr1_z = c2d(Gr1_v, Tsw, ['Method','tustin','PrewarpFrequency', wo])
Gv_z1 = c2d(Gv_s, Tsw,['Method','tustin','PrewarpFrequency', (wo)])
Bv = bv_z + Gr1_z

Gr3_z = c2d(Gr3_i, Tsw, ['Method','tustin','PrewarpFrequency', (3*wo)])
Gr5_z = c2d(Gr5_i, Tsw, ['Method','tustin','PrewarpFrequency', (5*wo)])
Gr7_z = c2d(Gr7_i, Tsw, ['Method','tustin','PrewarpFrequency', (7*wo)])
Gi_z1 = c2d(Gpr_i, Tsw, ['Method','tustin','PrewarpFrequency', [(3*wo), (5*wo), (7*wo)]])

Gd_z = c2d(Gd, Tsw, 'tustin')
Gplant_z = c2d(Gp, Tsw, 'tustin')

Gc = 1/(C*s)
Gc_z = c2d(Gc, Tsw, 'tustin')

Gpr_ol = Gpr_i * Gi_ol
Gd_in_cl = feedback(Gpr_ol, 1)
Gd_out_oL = (Gv_s * Gpr_i * Gd)/(((L*s) + r + (Gpr_i * Gd))*(C*s))
Gd_out_cl = feedback(Gd_out_oL, 1)

Gzi_ol = Gi_z1*Gplant_z*Gd_z
Gzi_cl = feedback(Gzi_ol, 1)
Gzv_ol = (Gv_z1 * Gzi_cl * Gc_z)
Gzv_cl = feedback(Gzv_ol, 1)


fh = figure(1);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gpr_ol);
[mag2, phase2, w2] = bode(Gzi_ol);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');

legend('Current Open-loop TF in s-domain', 'Current Open-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

legend('Current Open-loop TF in s-domain', 'Current Open-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

fh = figure(2);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gd_in_cl);
[mag2, phase2, w2] = bode(Gzi_cl);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');
legend('Current Closed-loop TF in s-domain', 'Current Closed-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');
legend('Current Closed-loop TF in s-domain', 'Current Closed-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

fh = figure(3);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gd_out_oL);
[mag2, phase2, w2] = bode(Gzv_ol);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');
legend('Voltage Open-loop TF in s-domain', 'Voltage Open-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');
legend('Voltage Open-loop TF in s-domain', 'Voltage Open-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;


fh = figure(4);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gd_out_cl);
[mag2, phase2, w2] = bode(Gzv_cl);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');
legend('Voltage Closed-loop TF in s-domain', 'Voltage Closed-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');
legend('Voltage Closed-loop TF in s-domain', 'Voltage Closed-loop TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

fh = figure(5);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

% Get frequency response data for both transfer functions
[mag1, phase1, w1] = bode(Gd);
[mag2, phase2, w2] = bode(Gd_z);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');
legend('Delay TF in s-domain', 'Delay TF in z-domain');
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

Gi_sen_s = feedback(1, Gpr_ol)
Gi_sen_z = feedback(1, Gzi_ol)

fh = figure(6);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gi_sen_s);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

fh = figure(7);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];


[mag1, phase1, w1] = bode(Gi_sen_z);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

%sentivity peak at 0dB gain meaning a gain of 1 which is fine

% Create a time vector
t = 0:Tsw:20;

% Generate sine input
f = 400; % frequency of sine wave
u = 115*sin(2*pi*f*t);

% Simulate the system response
y = lsim(Gzv_cl, u, t);

% Plot the results
fh = figure(8);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];
plot(t, u, 'b--', t, y, 'r-')
legend('Input', 'Output')
xlim([0 0.045])
xlabel('Time')
ylabel('Amplitude')
%title('Sine Input Response')
grid on

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;


fh = figure(9);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gv_s);
[mag2, phase2, w2] = bode(Gv_z1);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');

legend('TF in s-domain', 'TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

legend('TF in s-domain', 'TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

fh = figure(10);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gpr_i);
[mag2, phase2, w2] = bode(Gi_z1);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');

legend('TF in s-domain', 'TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');
legend('TF in s-domain', 'TF in z-domain')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;
