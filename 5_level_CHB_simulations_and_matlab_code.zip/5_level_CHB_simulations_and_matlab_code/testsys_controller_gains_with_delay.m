clc, clear
s= tf('s');
fsw = 12000;
Tsw = 1/fsw;
L = 13e-06;
r = 0.005;
C = 400e-06;
wc = 10;
wo = 2*pi*400;
kv_n = 1.1;

[n1,d1] = pade((3*Tsw/2), 1);

Gd = tf (n1,d1)


Gp = 1/((L*s) + r)
Gi_ol = Gd*Gp
%sisotool(Gi_ol)
kp_in = 0.1;


fh = figure(1);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(kp_in * Gi_ol);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;



Gr3_i = (0.5*s)/((s^2) + (2*wc*s) + ((3*wo)^2))
Gr5_i = (0.5*s)/((s^2) + (2*wc*s) + ((5*wo)^2))
Gr7_i = (0.5*s)/((s^2) + (2*wc*s) + ((7*wo)^2))

Gv_s = kv_n + ((2300*s)/(s^2 + (2*wc*s) + (wo)^2))

Gpr_i = kp_in + Gr3_i + Gr5_i + Gr7_i
Gpr_i1 = kp_in;

Gpr_ol = Gpr_i * Gi_ol
Gpr_ol1 = Gpr_i1 * Gi_ol
%sisotool(Gpr_ol)
Gd_out_oL = (Gv_s * Gpr_i * Gd)/(((L*s) + r + (Gpr_i * Gd))*(C*s))
Gd_out_oL1 = (Gv_s * Gpr_i1 * Gd)/(((L*s) + r + (Gpr_i1 * Gd))*(C*s))
%sisotool(Gd_out_oL)
Gc = 1/(C*s)
G_out_oL = (Gv_s * Gpr_i)/(((L*s) + r + Gpr_i)*(C*s))
G_out_oL1 = (Gv_s * Gpr_i1)/(((L*s) + r + Gpr_i1)*(C*s))

G_out_cl = feedback(G_out_oL, 1)
G_out_cl1 = feedback(G_out_oL1, 1)

Gd_in_cl = feedback(Gpr_ol, 1)


fh = figure(2);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];


[mag1, phase1, w1] = bode(Gpr_ol);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;


fh = figure(3);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];


[mag1, phase1, w1] = bode(Gd_in_cl);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;


Gd_out_cl = feedback(Gd_out_oL, 1)
Gd_out_cl1 = feedback(Gd_out_oL1, 1)


fh = figure(4);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];


[mag1, phase1, w1] = bode(Gd_out_oL);

subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)));
grid on;
ylabel('Magnitude (dB)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1));
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;


Gd_out_cl = feedback(Gd_out_oL, 1)
Gd_out_cl1 = feedback(Gd_out_oL1, 1)

fh = figure(5);
fh.Units = "centimeters";
fh.Position = [5 5 20 12];

[mag1, phase1, w1] = bode(Gd_out_cl);
[mag2, phase2, w2] = bode(Gd_out_cl1);

% Plot magnitude
subplot(2,1,1);
semilogx(w1, mag2db(squeeze(mag1)), 'b', w2, mag2db(squeeze(mag2)), 'r');
grid on;
ylabel('Magnitude (dB)');

legend('Inner PR controller', 'Inner P controller')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Plot phase
subplot(2,1,2);
semilogx(w1, squeeze(phase1), 'b', w2, squeeze(phase2), 'r');
grid on;
ylabel('Phase (deg)');
xlabel('Frequency (rad/s)');

legend('Inner PR controller', 'Inner P controller')
ax = gca;
ax.FontName = 'Times';
ax.FontSize = 10;

% Create a time vector
t = 0:Tsw/2:20;

% Generate sine input
f = 400; % frequency of sine wave
u = 115*sin(2*pi*f*t);

% Simulate the system response
y = lsim(Gd_out_cl, u, t);

% Plot the results
figure(6)
plot(t, u, 'b--', t, y, 'r-')
legend('Input', 'Output')
xlabel('Time')
ylabel('Amplitude')
title('Sine Input Response')
grid on
